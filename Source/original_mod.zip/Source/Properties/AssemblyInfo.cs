﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SWSaber")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SWSaberDLL")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("a8e081b6-8768-4fe9-817f-f0ee42cf13ef")]

[assembly: AssemblyVersion("1.17.0.3")]
[assembly: AssemblyFileVersion("1.17.0.3")]
