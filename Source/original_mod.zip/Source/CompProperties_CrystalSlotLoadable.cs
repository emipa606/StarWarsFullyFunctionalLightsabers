﻿using CompSlotLoadable;

namespace SWSaber
{
    public class CompProperties_CrystalSlotLoadable : CompProperties_SlotLoadable
    {
        public CompProperties_CrystalSlotLoadable()
        {
            compClass = typeof(CompCrystalSlotLoadable);
        }
    }
}