# Star Wars - Fully Functional Lightsabers
Adds full-SFX lightsabers that can be activated, loaded with crystals, and deflect bullets.

**This mod requires JecsTools to run properly.**
https://github.com/jecrell/JecsTools
